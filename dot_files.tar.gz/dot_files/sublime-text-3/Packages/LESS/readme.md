# LESS syntax package for Sublime Text 3

Based off the CSS.tmLanguage shipped with ST3.

Provides syntax highlighting for `.less` files + support for comment-toggle commands. Currently more love is needed on this due to changes made to honor the CSS value completions that Sublime Text 3 ships with.

Planned to provide mixins/variable completions.
