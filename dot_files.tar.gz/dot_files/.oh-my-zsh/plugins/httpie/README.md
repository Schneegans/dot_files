## HTTPie
**Maintainer:** [lululau](https://github.com/lululau)

This plugin adds completion for HTTPie, which is a command line HTTP client, a user-friendly cURL replacement. 

[HTTPie Homepage](http://httpie.org)
